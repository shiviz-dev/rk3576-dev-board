/*
 * Copyright 2022 Rockchip Electronics Co. LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __VDPU382_H265D_H__
#define __VDPU382_H265D_H__

#include "vdpu382_com.h"

typedef struct Vdpu382RegH265d_t {
    struct SWREG64_H26X_SET {
        RK_U32      h26x_frame_orslice      : 1;
        RK_U32      h26x_rps_mode           : 1;
        RK_U32      h26x_stream_mode        : 1;
        RK_U32      h26x_stream_lastpacket  : 1;
        RK_U32      h264_firstslice_flag    : 1;
        RK_U32      reserve                 : 27;
    } reg64;

    struct SWREG65_CUR_POC {
        RK_U32      cur_top_poc : 32;
    } reg65;

    struct SWREG66_H264_CUR_POC1 {
        RK_U32      cur_bot_poc : 32;
    } reg66;

    RK_U32  reg67_82_ref_poc[16];


    struct SWREG83_98_H264_REF_POC {
        RK_U32      ref_poc : 32;
    } ref_poc_no_use[16];

    /*     struct SWREG99_HEVC_REF_VALID{
            RK_U32      hevc_ref_valid  : 15;
            RK_U32      reserve         : 17;
        }hevc_ref_valid; */

    struct SWREG99_HEVC_REF_VALID {
        RK_U32      hevc_ref_valid_0    : 1;
        RK_U32      hevc_ref_valid_1    : 1;
        RK_U32      hevc_ref_valid_2    : 1;
        RK_U32      hevc_ref_valid_3    : 1;
        RK_U32      reserve0            : 4;
        RK_U32      hevc_ref_valid_4    : 1;
        RK_U32      hevc_ref_valid_5    : 1;
        RK_U32      hevc_ref_valid_6    : 1;
        RK_U32      hevc_ref_valid_7    : 1;
        RK_U32      reserve1            : 4;
        RK_U32      hevc_ref_valid_8    : 1;
        RK_U32      hevc_ref_valid_9    : 1;
        RK_U32      hevc_ref_valid_10   : 1;
        RK_U32      hevc_ref_valid_11   : 1;
        RK_U32      reserve2            : 4;
        RK_U32      hevc_ref_valid_12   : 1;
        RK_U32      hevc_ref_valid_13   : 1;
        RK_U32      hevc_ref_valid_14   : 1;
        RK_U32      reserve3            : 5;
    } reg99;

    RK_U32  reg100_102_no_use[3];

    struct SWREG103_HEVC_MVC0 {
        RK_U32      ref_pic_layer_same_with_cur : 16;
        RK_U32      reserve                     : 16;
    } reg103;

    struct SWREG104_HEVC_MVC1 {
        RK_U32      poc_lsb_not_present_flag        : 1;
        RK_U32      num_direct_ref_layers           : 6;
        RK_U32      reserve0                        : 1;

        RK_U32      num_reflayer_pics               : 6;
        RK_U32      default_ref_layers_active_flag  : 1;
        RK_U32      max_one_active_ref_layer_flag   : 1;

        RK_U32      poc_reset_info_present_flag     : 1;
        RK_U32      vps_poc_lsb_aligned_flag        : 1;
        RK_U32      mvc_poc15_valid_flag            : 1;
        RK_U32      reserve1                        : 13;
    } reg104;

    struct SWREG105_111_NO_USE_REGS {
        RK_U32  no_use_regs[7];
    } no_use_regs;

    struct SWREG112_ERROR_REF_INFO {
        RK_U32      avs2_ref_error_field        : 1;
        RK_U32      avs2_ref_error_topfield     : 1;
        RK_U32      ref_error_topfield_used     : 1;
        RK_U32      ref_error_botfield_used     : 1;
        RK_U32      reserve                     : 28;
    } reg112;

} Vdpu382RegH265d;

typedef struct Vdpu382RegH265dAddr_t {
    struct SWREG160_VP9_DELTA_PROB_BASE {
        RK_U32 vp9_delta_prob_base  : 32;
    } reg160_no_use;

    RK_U32  reg161_pps_base;

    RK_U32 reg162_no_use;

    RK_U32  reg163_rps_base;

    RK_U32  reg164_179_ref_base[16];

    RK_U32  reg180_scanlist_addr;

    RK_U32  reg181_196_colmv_base[16];

    RK_U32  reg197_cabactbl_base;

    RK_U32  reg198_scale_down_luma_base;

    RK_U32  reg199_scale_down_chorme_base;
} Vdpu382RegH265dAddr;

typedef struct Vdpu382H265dHighPoc_t {
    /* SWREG200 */
    struct SWREG200_REF0_7_POC_HIGHBIT {
        RK_U32      ref0_poc_highbit        : 4;
        RK_U32      ref1_poc_highbit        : 4;
        RK_U32      ref2_poc_highbit        : 4;
        RK_U32      ref3_poc_highbit        : 4;
        RK_U32      ref4_poc_highbit        : 4;
        RK_U32      ref5_poc_highbit        : 4;
        RK_U32      ref6_poc_highbit        : 4;
        RK_U32      ref7_poc_highbit        : 4;
    } reg200;
    struct SWREG201_REF8_15_POC_HIGHBIT {
        RK_U32      ref8_poc_highbit        : 4;
        RK_U32      ref9_poc_highbit        : 4;
        RK_U32      ref10_poc_highbit       : 4;
        RK_U32      ref11_poc_highbit       : 4;
        RK_U32      ref12_poc_highbit       : 4;
        RK_U32      ref13_poc_highbit       : 4;
        RK_U32      ref14_poc_highbit       : 4;
        RK_U32      ref15_poc_highbit       : 4;
    } reg201;
    struct SWREG200_REF16_23_POC_HIGHBIT {
        RK_U32      ref16_poc_highbit       : 4;
        RK_U32      ref17_poc_highbit       : 4;
        RK_U32      ref18_poc_highbit       : 4;
        RK_U32      ref19_poc_highbit       : 4;
        RK_U32      ref20_poc_highbit       : 4;
        RK_U32      ref21_poc_highbit       : 4;
        RK_U32      ref22_poc_highbit       : 4;
        RK_U32      ref23_poc_highbit       : 4;
    } reg202;
    struct SWREG200_REF24_31_POC_HIGHBIT {
        RK_U32      ref24_poc_highbit       : 4;
        RK_U32      ref25_poc_highbit       : 4;
        RK_U32      ref26_poc_highbit       : 4;
        RK_U32      ref27_poc_highbit       : 4;
        RK_U32      ref28_poc_highbit       : 4;
        RK_U32      ref29_poc_highbit       : 4;
        RK_U32      ref30_poc_highbit       : 4;
        RK_U32      ref31_poc_highbit       : 4;
    } reg203;
    struct SWREG200_CUR_POC_HIGHBIT {
        RK_U32      cur_poc_highbit         : 4;
        RK_U32      reserver                : 28;
    } reg204;

    struct SWREG205_DEBUG_INFO {
        RK_U32      force_softreset_valid   : 1;
        RK_U32      force_mmureset_valid    : 1;
        RK_U32      reserve0                : 2;
        RK_U32      error_auto_rst_disable  : 1;
        RK_U32      right_auto_rst_disable  : 1;
        RK_U32      buf_empty_security_en   : 1;
        RK_U32      coord_realtime_report_en : 1;

        RK_U32      fetchcmd_merge_dis      : 1;
        RK_U32      dec_timeout_dis         : 1;
        RK_U32      reg_cfg_wr_dis          : 1;
        RK_U32      reserve1                : 1;
        RK_U32      force_busidle_req       : 1;
        RK_U32      mmu_force_busidle_req   : 1;
        RK_U32      mmu_sel                 : 1;
        RK_U32      reserve2                : 17;

    } reg205;
} Vdpu382H2645HighPoc_t;

typedef struct Vdpu382H265dRegSet_t {
    Vdpu382RegCommon        common;
    Vdpu382RegH265d         h265d_param;
    Vdpu382RegCommonAddr    common_addr;
    Vdpu382RegH265dAddr     h265d_addr;
    Vdpu382H2645HighPoc_t   highpoc;
    Vdpu382RegIrqStatus     irq_status;
    Vdpu382RegStatistic     statistic;
} Vdpu382H265dRegSet;

#endif /* __VDPU382_H265D_H__ */
