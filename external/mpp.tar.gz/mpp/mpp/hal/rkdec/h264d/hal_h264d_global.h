/* SPDX-License-Identifier: Apache-2.0 OR MIT */
/*
 * Copyright (c) 2015 Rockchip Electronics Co., Ltd.
 */

#ifndef __HAL_H264D_GLOBAL_H__
#define __HAL_H264D_GLOBAL_H__

#include "mpp_hal.h"
#include "mpp_debug.h"
#include "mpp_device.h"
#include "hal_bufs.h"

#include "dxva_syntax.h"
#include "h264d_syntax.h"

#define H264D_DBG_ERROR             (0x00000001)
#define H264D_DBG_ASSERT            (0x00000002)
#define H264D_DBG_WARNNING          (0x00000004)
#define H264D_DBG_LOG               (0x00000008)

#define H264D_DBG_HARD_MODE         (0x00000010)

extern RK_U32 hal_h264d_debug;


#define H264D_DBG(level, fmt, ...)\
do {\
    if (level & hal_h264d_debug)\
        { mpp_log(fmt, ## __VA_ARGS__); }\
} while (0)


#define H264D_ERR(fmt, ...)\
do {\
    if (H264D_DBG_ERROR & hal_h264d_debug)\
        { mpp_log(fmt, ## __VA_ARGS__); }\
} while (0)

#define ASSERT(val)\
do {\
    if (H264D_DBG_ASSERT & hal_h264d_debug)\
        { mpp_assert(val); }\
} while (0)

#define H264D_WARNNING(fmt, ...)\
do {\
    if (H264D_DBG_WARNNING & hal_h264d_debug)\
        { mpp_log(fmt, ## __VA_ARGS__); }\
} while (0)

#define H264D_LOG(fmt, ...)\
do {\
    if (H264D_DBG_LOG & hal_h264d_debug)\
        { mpp_log(fmt, ## __VA_ARGS__); }\
} while (0)


//!< vaule check
#define VAL_CHECK(ret, val, ...)\
do{\
    if (!(val)){\
        ret = MPP_ERR_VALUE; \
        H264D_WARNNING("value error(%d).\n", __LINE__); \
        goto __FAILED; \
}} while (0)
//!< memory malloc check
#define MEM_CHECK(ret, val, ...)\
do{\
    if (!(val)) {\
        ret = MPP_ERR_MALLOC; \
        H264D_ERR("malloc buffer error(%d).\n", __LINE__); \
        ASSERT(0); goto __FAILED; \
}} while (0)


//!< input check
#define INP_CHECK(ret, val, ...)\
do{\
    if ((val)) {\
        ret = MPP_ERR_INIT; \
        H264D_WARNNING("input empty(%d).\n", __LINE__); \
        goto __RETURN; \
}} while (0)
//!< function return check
#define FUN_CHECK(val)\
do{\
    if ((val) < 0) {\
        H264D_WARNNING("Function error(%d).\n", __LINE__); \
        goto __FAILED; \
}} while (0)


typedef struct h264d_hal_ctx_t {
    const MppHalApi          *hal_api;

    DXVA_PicParams_H264_MVC  *pp;
    DXVA_Qmatrix_H264        *qm;
    RK_U32                   slice_num;
    DXVA_Slice_H264_Short    *slice_short;  //!<  MAX_SLICES
    DXVA_Slice_H264_Long     *slice_long;   //!<  MAX_SLICES
    RK_U8                    *bitstream;
    RK_U32                   strm_len;

    void                     *priv;       //!< resert data for extent
    //!< add
    HalDecTask               *in_task;
    MppBufSlots              frame_slots;
    MppBufSlots              packet_slots;
    MppDecCfgSet             *cfg;
    MppBufferGroup           buf_group;
    HalBufs                  cmv_bufs;
    RK_S32                   mv_size;
    RK_S32                   mv_count;

    MppCbCtx                 *dec_cb;
    MppDev                   dev;
    void                     *reg_ctx;
    RK_U32                   fast_mode;

    const MppDecHwCap        *hw_info;
} H264dHalCtx_t;

extern const RK_U32 h264_cabac_table[928];

#endif /*__HAL_H264D_GLOBAL_H__*/
